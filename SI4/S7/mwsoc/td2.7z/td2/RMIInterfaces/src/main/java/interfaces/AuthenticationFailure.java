package interfaces;

import java.io.Serializable;

public class AuthenticationFailure extends Exception implements Serializable {
}
