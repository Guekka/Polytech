package interfaces;

import java.io.Serializable;

public class InvalidVoteCredentials extends Exception implements Serializable {

}
