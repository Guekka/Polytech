package data;

import java.io.Serializable;

public record ID(String id) implements Serializable {
}
