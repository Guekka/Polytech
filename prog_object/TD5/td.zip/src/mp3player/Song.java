package mp3player;

import utils.Utils;

public class Song {
    private final String filePath;
    private final String title;
    private final String artist;

    public Song(String filePath) throws NonAvailableFileException {
        // check if file exist
        if(!new java.io.File(filePath).exists()) {
            throw new NonAvailableFileException("File " + filePath + " does not exist");
        }

        this.filePath = filePath;

        String[] parts = Utils.pathStem(this.filePath).split("-");
        if(parts.length != 2) {
            throw new NonAvailableFileException("File " + filePath + " has not a valid file name");
        }
        this.artist = Utils.parseCamelCase(parts[0]);
        this.title = Utils.parseCamelCase(parts[1]);
    }

    public String getFilepath() {
        return filePath;
    }

    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }
}
