package mp3player;

import org.junit.jupiter.api.Test;

public class MusicBankTest {

}
