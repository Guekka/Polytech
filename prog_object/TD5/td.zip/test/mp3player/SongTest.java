package mp3player;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


public class SongTest {
    private static final String RESOURCE_PATH = System.getProperty("user.dir") + "/resources/audio/";
    @Test
    void testConstructor() {
        Song s = null;
        try {
            s = new Song(RESOURCE_PATH + "BigBillBroonzy-BabyPleaseDontGo1.mp3");
        } catch (NonAvailableFileException e) {
            fail("The file cannot be opened : " + e);
        }
        assertEquals(RESOURCE_PATH + "BigBillBroonzy-BabyPleaseDontGo1.mp3", s.getFilepath());
    }

    @Test
    void testConstructorWithFileNotExisting() {
        assertThrows(NonAvailableFileException.class, ()-> new Song("unknown.mp3"));
    }

    @Test
    void testParsing() {
        Song s = null;
        try {
            s = new Song(RESOURCE_PATH+ "BigBillBroonzy-BabyPleaseDontGo1.mp3");
        } catch (NonAvailableFileException e) {
            fail("The file cannot be opened : " + e);
        }
        assertEquals("Big Bill Broonzy", s.getArtist());
        assertEquals("Baby Please Dont Go 1", s.getTitle());
    }
}
